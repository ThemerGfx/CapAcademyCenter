# jQuery search and filter from div 


![Alt Text](https://github.com/kmrifat/jQuery-Filter-Search-div/blob/master/demo.gif?raw=true)

I recently needed to filter divs by their class when people pressed the appropriate button and search by given value. At first I took a look at plugins like Isotope, MixItUp, but they bring in thousands of lines of unwanted code and layout features that are useless to me. So, i decide to write one.
